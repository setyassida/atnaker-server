<?php
class Majikan extends ActiveRecord\Model
{}
?>